"""XXT Sign Server — lightweight Chaoxing batch sign-in proxy.

No user accounts. Users add Chaoxing credentials which are encrypted at rest.
Anyone with the app can trigger batch sign-in for all stored accounts.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Form, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
import datetime
import base64
import io
from PIL import Image
from pyzbar.pyzbar import decode as qr_decode

from config import HOST, PORT
from database import init_db, async_session
from models import ChaoxingAccount
from encryption import (
    encrypt_credentials, decrypt_credentials,
    encrypt_cookies, decrypt_cookies,
)
from chaoxing_api import (
    chaoxing_login, get_courses, get_active_sign_tasks,
    execute_normal_sign, execute_qr_sign,
    execute_location_sign, execute_photo_sign,
    ChaoxingSession, ActiveSignTask,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    print(f"[OK] Chaoxing Sign Server on {HOST}:{PORT}")
    yield


app = FastAPI(
    title="XXT Sign Server",
    description="学习通批量签到 — 直接使用学习通账号",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _build_session(acc: ChaoxingAccount) -> ChaoxingSession | None:
    """Restore a Chaoxing session from stored account."""
    creds = decrypt_credentials(acc.phone_encrypted, acc.password_encrypted)
    cached = decrypt_cookies(acc.cookies_encrypted)
    if cached:
        return ChaoxingSession(cookies=cached, uid=acc.uid, name=acc.real_name, phone=creds["phone"])

    session = await chaoxing_login(creds["phone"], creds["password"])
    if session:
        async with async_session() as db:
            db_acc = await db.get(ChaoxingAccount, acc.id)
            if db_acc:
                db_acc.cookies_encrypted = encrypt_cookies(session.cookies)
                db_acc.uid = session.uid
                db_acc.real_name = session.name
                await db.commit()
    return session


async def _get_all_active_sessions() -> list[tuple[ChaoxingAccount, ChaoxingSession]]:
    """Build sessions for all active accounts."""
    sessions = []
    async with async_session() as db:
        result = await db.execute(
            select(ChaoxingAccount).where(ChaoxingAccount.is_active == True)
        )
        for acc in result.scalars().all():
            try:
                s = await _build_session(acc)
                if s:
                    sessions.append((acc, s))
            except Exception:
                pass
    return sessions


# ---------------------------------------------------------------------------
# Account management (no auth required)
# ---------------------------------------------------------------------------

@app.post("/api/accounts/add")
async def add_account(
    phone: str = Form(...),
    password: str = Form(...),
    display_name: str = Form(""),
):
    """Add a Chaoxing account. Credentials are encrypted before storage."""
    # Verify credentials work
    session = await chaoxing_login(phone, password)
    if not session:
        raise HTTPException(400, detail="学习通登录失败，请检查手机号和密码")

    encrypted = encrypt_credentials(phone, password)

    async with async_session() as db:
        acc = ChaoxingAccount(
            phone_encrypted=encrypted["phone_encrypted"],
            password_encrypted=encrypted["password_encrypted"],
            display_name=display_name or session.name or phone[-4:],
            cookies_encrypted=encrypt_cookies(session.cookies),
            real_name=session.name,
            uid=session.uid,
        )
        db.add(acc)
        await db.commit()
        await db.refresh(acc)

        return {
            "id": acc.id,
            "display_name": acc.display_name,
            "real_name": acc.real_name,
            "uid": acc.uid,
        }


@app.get("/api/accounts/list")
async def list_accounts():
    """List all stored accounts (phone masked for privacy)."""
    async with async_session() as db:
        result = await db.execute(
            select(ChaoxingAccount).where(ChaoxingAccount.is_active == True)
        )
        accounts = []
        for acc in result.scalars().all():
            try:
                creds = decrypt_credentials(acc.phone_encrypted, acc.password_encrypted)
                phone_masked = creds["phone"][:3] + "****" + creds["phone"][-3:]
            except Exception:
                phone_masked = "****"
            accounts.append({
                "id": acc.id,
                "display_name": acc.display_name,
                "real_name": acc.real_name,
                "phone_masked": phone_masked,
                "uid": acc.uid,
                "created_at": acc.created_at.isoformat() if acc.created_at else None,
            })
        return accounts


@app.delete("/api/accounts/{account_id}")
async def delete_account(account_id: int):
    """Deactivate a stored account."""
    async with async_session() as db:
        acc = await db.get(ChaoxingAccount, account_id)
        if not acc:
            raise HTTPException(404, detail="账号不存在")
        acc.is_active = False
        await db.commit()
    return {"message": "账号已删除"}


# ---------------------------------------------------------------------------
# Sign-in operations
# ---------------------------------------------------------------------------

@app.post("/api/sign/check")
async def check_tasks(
    phone: str = Form(...),
    password: str = Form(...),
):
    """Check active sign-in tasks for a Chaoxing account."""
    session = await chaoxing_login(phone, password)
    if not session:
        raise HTTPException(400, detail="学习通登录失败")

    courses = await get_courses(session)
    tasks = await get_active_sign_tasks(session, courses)

    return {
        "courses_count": len(courses),
        "tasks": [
            {
                "active_id": t.active_id,
                "course_name": t.course_name,
                "sign_type": t.sign_type,
                "course_id": t.course_id,
                "class_id": t.class_id,
            }
            for t in tasks
        ],
        "uid": session.uid,
        "name": session.name,
    }


@app.post("/api/sign/execute")
async def execute_sign(
    active_id: str = Form(...),
    sign_type: str = Form("normal"),
    latitude: str = Form("-1"),
    longitude: str = Form("-1"),
    address: str = Form("中国"),
    enc: str = Form(""),
    account_ids: str = Form(""),  # empty = all accounts
):
    """Execute sign-in for stored accounts. Default: all accounts."""
    sessions = await _get_all_active_sessions()

    # Filter if account_ids specified
    if account_ids:
        ids = set(int(x.strip()) for x in account_ids.split(",") if x.strip())
        sessions = [(a, s) for a, s in sessions if a.id in ids]

    if not sessions:
        raise HTTPException(400, detail="没有可用的学习通账号，请先添加账号")

    task = ActiveSignTask(active_id=active_id, sign_type=sign_type)
    results = []

    for acc, session in sessions:
        try:
            if sign_type == "qr":
                r = await execute_qr_sign(session, task, enc)
            elif sign_type == "location":
                r = await execute_location_sign(session, task, latitude, longitude, address)
            else:
                r = await execute_normal_sign(session, task, latitude, longitude, address)
            r["account_name"] = acc.real_name or acc.display_name
            r["account_id"] = acc.id
            results.append(r)
        except Exception as e:
            results.append({
                "success": False, "message": str(e),
                "account_name": acc.real_name or acc.display_name,
                "account_id": acc.id,
            })

    return {
        "total": len(results),
        "success_count": sum(1 for r in results if r.get("success")),
        "results": results,
    }


@app.post("/api/sign/execute-selected")
async def execute_selected(
    active_id: str = Form(...),
    sign_type: str = Form("normal"),
    latitude: str = Form("-1"),
    longitude: str = Form("-1"),
    address: str = Form("中国"),
    enc: str = Form(""),
    phones: str = Form(...),  # comma-separated phone numbers
):
    """Execute sign-in for specific phone numbers."""
    target_phones = set(p.strip() for p in phones.split(",") if p.strip())
    if not target_phones:
        raise HTTPException(400, detail="请指定要签到的手机号")

    sessions = await _get_all_active_sessions()

    # Filter by phone
    matching = []
    for acc, s in sessions:
        try:
            creds = decrypt_credentials(acc.phone_encrypted, acc.password_encrypted)
            if creds["phone"] in target_phones:
                matching.append((acc, s))
        except Exception:
            pass

    if not matching:
        raise HTTPException(400, detail="未找到匹配的账号")

    task = ActiveSignTask(active_id=active_id, sign_type=sign_type)
    results = []
    for acc, session in matching:
        try:
            if sign_type == "qr":
                r = await execute_qr_sign(session, task, enc)
            elif sign_type == "location":
                r = await execute_location_sign(session, task, latitude, longitude, address)
            else:
                r = await execute_normal_sign(session, task, latitude, longitude, address)
            r["account_name"] = acc.real_name or acc.display_name
            r["account_id"] = acc.id
            results.append(r)
        except Exception as e:
            results.append({
                "success": False, "message": str(e),
                "account_name": acc.real_name or acc.display_name,
                "account_id": acc.id,
            })

    return {
        "total": len(results),
        "success_count": sum(1 for r in results if r.get("success")),
        "results": results,
    }


# ---------------------------------------------------------------------------
# QR code decoding
# ---------------------------------------------------------------------------

@app.post("/api/sign/decode-qr")
async def decode_qr(image: UploadFile = File(...)):
    """Decode a QR code from an uploaded image, extract the enc parameter."""
    try:
        data = await image.read()
        img = Image.open(io.BytesIO(data))
        results = qr_decode(img)

        if not results:
            raise HTTPException(400, detail="未检测到二维码，请确保二维码完整清晰")

        # Get the first QR code content
        qr_text = results[0].data.decode("utf-8", errors="ignore")
        print(f"[QR] Decoded: {qr_text[:200]}")

        # Extract enc parameter from QR URL
        # Typical formats:
        # https://mobilelearn.chaoxing.com/...?enc=XXXXXXXX
        # or just: enc=XXXXXXXX
        import re
        enc_match = re.search(r'enc=([A-Za-z0-9]+)', qr_text)
        if enc_match:
            enc = enc_match.group(1)
            return {"enc": enc, "raw": qr_text}

        # If no enc param, return the raw text for manual handling
        return {"enc": qr_text, "raw": qr_text}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, detail=f"二维码解码失败: {str(e)}")


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "2.0.0"}


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=HOST, port=PORT, reload=True)
