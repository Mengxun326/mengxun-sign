"""Database models — simplified: only Chaoxing accounts, no user system."""
import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from database import Base


class ChaoxingAccount(Base):
    """Encrypted Chaoxing (学习通) account credentials."""
    __tablename__ = "chaoxing_accounts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    # Encrypted fields (AES-256, base64 encoded)
    phone_encrypted = Column(Text, nullable=False)
    password_encrypted = Column(Text, nullable=False)
    # Display name
    display_name = Column(String(256), default="")
    # Status
    is_active = Column(Boolean, default=True)
    # Cached session cookies (encrypted)
    cookies_encrypted = Column(Text, default="")
    # Metadata from Chaoxing
    real_name = Column(String(256), default="")
    uid = Column(String(64), default="")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
